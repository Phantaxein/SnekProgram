﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SFML.System;
using SFML.Window;
using SFML.Graphics;
using Snake.ProgramSystem;
namespace Snake.Game
{
    public class Snake : ICollider, ISnake
    {
        ICollisionHandler CollisionHandler;
        Direction direction;
        UpdateHandler updateHandler;
        public bool IsDead;
        public int MoveCounter;
        Tail myTail;
        public int Speed
        {
            get
            {
                return updateHandler.UpdatesNeededToTrigger;
            }
            set
            {
                updateHandler.ChangeUpdateRate(value);
            }
        }

        private float _Radius;
        float Radius
        {
            get
            {
                return _Radius;
            }
            set
            {
                _Radius = value;
                circleShape.Radius = value;
            }
        }

        SnakeVector2f _Position;

        public SnakeVector2f Position
        {
            get
            {
                return _Position;
            }
            set
            {
                _Position = value;
                circleShape.Position = value;
            }
        }

        CircleShape circleShape;

        public Snake(ICollisionHandler collisionHandler)
        {
            circleShape = new CircleShape()
            {
                OutlineColor = Color.White,
                OutlineThickness = -1,
                FillColor = Color.Red
            };

            updateHandler = new UpdateHandler(0);

            myTail = new Tail(0, collisionHandler);
            Speed = 10;
            direction = Direction.Right;
            Radius = 8;
            Position = new SnakeVector2f(5, 5);
            IsDead = false;
            CollisionHandler = collisionHandler;
            CollisionHandler.Register(this);
        }

        public Direction GetDirection()
        {
            return direction;
        }

        public void Update()
        {
            SnakeVector2f pendingPosition = new SnakeVector2f(0, 0);

            switch (direction)
            {
                case Direction.Left: pendingPosition = Position + new SnakeVector2f(-1, 0); break;
                case Direction.Right: pendingPosition = Position + new SnakeVector2f(1, 0); break;
                case Direction.Up: pendingPosition = Position + new SnakeVector2f(0, -1); break;
                case Direction.Down: pendingPosition = Position + new SnakeVector2f(0, 1); break;
            }

            Type type = CollisionHandler.RequestMove(new SnakeRectangle(pendingPosition, new SnakeVector2f(1, 1)), this);

            switch (type?.Name)
            {
                case nameof(Tail.TailSection):
                case nameof(Wall): Collision(type); break;
                case nameof(Food):
                    myTail.Grow(Position);
                    myTail.Update(Position);
                    Position = pendingPosition;
                    break;
                default:
                    myTail.Update(Position);
                    Position = pendingPosition;
                    break;
            }
        }

        public void KeyPress(int directionRotation)
        {
            SnakeVector2f pendingPosition = new SnakeVector2f(0, 0);
            Direction prevDir = direction;
            direction = (Direction)directionRotation;

            switch (direction)
            {
                case Direction.Left: pendingPosition = Position + new SnakeVector2f(-1, 0); break;
                case Direction.Right: pendingPosition = Position + new SnakeVector2f(1, 0); break;
                case Direction.Up: pendingPosition = Position + new SnakeVector2f(0, -1); break;
                case Direction.Down: pendingPosition = Position + new SnakeVector2f(0, 1); break;
            }
            Type type = CollisionHandler.AskForMove(new SnakeRectangle(pendingPosition, new SnakeVector2f(1, 1)), this);
            if(type?.Name == nameof(Tail.TailSection)) { direction = prevDir; }
        }

        public void Draw(RenderTarget target, RenderStates states)
        {
            circleShape.Draw(target, states);
            myTail.Draw(target, states);
        }

        public void Collision(Type type)
        {
            switch (type.Name)
            {
                case nameof(Wall): MoveCounter++; IsDead = true; break;
            }
        }

        public SnakeRectangle GetBounds()
        {
            return new SnakeRectangle(Position, new SnakeVector2f(1, 1));
        }

        public Type GetCollisionType()
        {
            return GetType();
        }

        public SnakeVector2f GetPosition()
        {
            return Position;
        }

        public enum Direction
        {
            Up = 0,
            Right = 1,
            Down = 2,
            Left = 3
        }

        private class Tail
        {
            int Size;
            List<TailSection> tail = new List<TailSection>();
            ICollisionHandler handler;
            public Tail(int size, ICollisionHandler handler)
            {
                Size = size;
                this.handler = handler;
            }

            public void Grow(SnakeVector2f position)
            {
                Size++;
                tail.Add(new TailSection(position, handler));
            }


            public void Update(SnakeVector2f position)
            {
                SnakeVector2f prevPos = position;
                foreach (TailSection sec in tail)
                {
                    SnakeVector2f temp = sec.Position;
                    sec.Position = prevPos;
                    prevPos = temp;
                }
            }
            public void Draw(RenderTarget window, RenderStates rs)
            {
                tail.ForEach(x => x.section.Draw(window, rs));
            }

            public class TailSection : ICollider
            {
                public CircleShape section;

                public SnakeVector2f Position
                {
                   get
                    {
                        return section.Position;
                    }
                    set
                    {
                        section.Position = value;
                    }
                }

                SnakeVector2f Size;

                public TailSection(SnakeVector2f position, ICollisionHandler handler)
                {
                    Size = new SnakeVector2f(1, 1);
                    section = new CircleShape()
                    {
                        OutlineColor = Color.White,
                        OutlineThickness = -1,
                        FillColor = Color.Blue
                    };
                    section.Radius = 8;
                    Position = position;
                    handler.Register(this);
                }

                public Type GetCollisionType()
                {
                    return typeof(Snake);
                }

                public void Collision(Type type)
                {
                        
                }

                public SnakeRectangle GetBounds()
                {
                    return new SnakeRectangle(Position, Size);
                }
            }
        }
    }
}

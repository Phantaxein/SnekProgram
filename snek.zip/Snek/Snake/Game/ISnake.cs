﻿using Snake.ProgramSystem;

namespace Snake.Game
{
    public interface ISnake
    {
        SnakeVector2f GetPosition();
    }
}
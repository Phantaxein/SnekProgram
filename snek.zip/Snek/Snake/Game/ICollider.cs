﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Snake.ProgramSystem;

namespace Snake.Game
{
    public interface ICollider
    {
        Type GetCollisionType();

        void Collision(Type type);

        SnakeRectangle GetBounds();
    }

}

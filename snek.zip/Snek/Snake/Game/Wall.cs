﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SFML.System;
using SFML.Window;
using SFML.Graphics;
using Snake.ProgramSystem;

namespace Snake.Game
{
    public class Wall : ICollider
    {
        SnakeVector2f Size;
        SnakeVector2f Position;
        RectangleShape rectangleShape;
        ICollisionHandler CollisionHandler;
        public Wall(SnakeVector2f size, SnakeVector2f position, ICollisionHandler collisionHandler)
        {
            Size = size;
            Position = position;

            rectangleShape = new RectangleShape(Size)
            {
                Position = Position,
                OutlineColor = Color.Green,
                FillColor = Color.Transparent,
                OutlineThickness = -1
            };
            CollisionHandler = collisionHandler;
            CollisionHandler.Register(this);
        }

        public void Update()
        {
            
        }

        public void KeyPress(Keyboard.Key key)
        {

        }

        public void Draw(RenderTarget target, RenderStates states)
        {
            rectangleShape.Draw(target, states);
        }

        public Type GetCollisionType()
        {
            return GetType();
        }

        public void Collision(Type type)
        {

        }

        public SnakeRectangle GetBounds()
        {
            return new SnakeRectangle(Position, Size);
        }
    }
}

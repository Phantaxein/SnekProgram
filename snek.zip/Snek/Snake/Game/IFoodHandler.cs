﻿namespace Snake.Game
{
    public interface IFoodHandler
    {
        void RemoveFood(Food food);
    }
}
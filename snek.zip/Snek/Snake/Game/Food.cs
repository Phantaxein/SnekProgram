﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SFML.System;
using SFML.Window;
using SFML.Graphics;
using Snake.ProgramSystem;

namespace Snake.Game
{
    public class Food : ICollider
    {
        ICollisionHandler CollisionHandler;
        IFoodHandler FoodHandler;

        public SnakeVector2f Position;

        CircleShape circleShape;

        public Food(IFoodHandler foodHandler, SnakeVector2f position, ICollisionHandler collisionHandler)
        {
            FoodHandler = foodHandler;
            Position = position;

            circleShape = new CircleShape()
            {
                Position = Position,
                Radius = 4,
                FillColor = Color.Green
            };

            circleShape.Position += SnakeVector2f.CenterOffSet(new Vector2f(circleShape.Radius * 2, circleShape.Radius * 2));

            CollisionHandler = collisionHandler;
            CollisionHandler.Register(this);

        }

        public void Collision(Type type)
        {
            switch (type.Name)
            {
                case nameof(Snake):FoodHandler.RemoveFood(this); CollisionHandler.Remove(this); break;
            }

        }

        public void Draw(RenderTarget target, RenderStates states)
        {
            circleShape.Draw(target, states);
        }

        public SnakeRectangle GetBounds()
        {
            return new SnakeRectangle(Position, new SnakeVector2f(1, 1));
        }

        public Type GetCollisionType()
        {
            return GetType();
        }
    }
}

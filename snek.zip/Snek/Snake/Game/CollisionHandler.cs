﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Snake.ProgramSystem;

namespace Snake.Game
{
    public class CollisionHandler : ICollisionHandler
    {
        List<ICollider> Colliders;

        public CollisionHandler()
        {
            Colliders = new List<ICollider>();
        }

        public void Register(ICollider collider)
        {
            if (!Colliders.Contains(collider))
            {
                Colliders.Add(collider);
            }
            else
            {
                throw new Exception("Already added this collider");
            }
        }

        public void Remove(ICollider collider)
        {
            if (Colliders.Contains(collider))
            {
                Colliders.Remove(collider);
            }
            else
            {
                throw new Exception("Already removed this collider");
            }
        }

        public Type RequestMove(SnakeRectangle requestedPosition, ICollider requestor)
        {
            foreach (var collider in Colliders)
            {
                if (collider != requestor)
                {
                    if (collider.GetBounds().Collides(requestedPosition))
                    {
                        collider.Collision(requestor.GetCollisionType());
                        return collider.GetType();
                    }
                }
            }

            return null;
        }
        public Type AskForMove(SnakeRectangle requestedPosition, ICollider requestor)
        {
            foreach (var collider in Colliders)
            {
                if (collider != requestor)
                {
                    if (collider.GetBounds().Collides(requestedPosition))
                    {
                        return collider.GetType();
                    }
                }
            }

            return null;
        }

        private double IsDeathHere(SnakeVector2f position)
        {
            foreach (var collider in Colliders)
            {
                if (collider.GetBounds().Collides(position))
                {
                    switch (collider.GetType().Name)
                    {
                        case nameof(Wall): return 1;
                        case nameof(Snake): return 1;
                    }
                }
            }

            return 0;
        }

        public List<double> GetData(Snake.Direction direction, SnakeVector2f position)
        {
            List<double> dataToReturn = new List<double>();

            switch (direction)
            {
                case Snake.Direction.Up:
                    dataToReturn.Add(IsDeathHere(position + new SnakeVector2f(0, -1)));
                    dataToReturn.Add(IsDeathHere(position + new SnakeVector2f(1, 0)));
                    dataToReturn.Add(IsDeathHere(position + new SnakeVector2f(-1, 0)));
                    break;
                case Snake.Direction.Right:
                    dataToReturn.Add(IsDeathHere(position + new SnakeVector2f(1, 0)));
                    dataToReturn.Add(IsDeathHere(position + new SnakeVector2f(0, 1)));
                    dataToReturn.Add(IsDeathHere(position + new SnakeVector2f(0, -1)));
                    break;
                case Snake.Direction.Down:
                    dataToReturn.Add(IsDeathHere(position + new SnakeVector2f(0, 1)));
                    dataToReturn.Add(IsDeathHere(position + new SnakeVector2f(1, 0)));
                    dataToReturn.Add(IsDeathHere(position + new SnakeVector2f(-1, 0)));
                    break;
                case Snake.Direction.Left:
                    dataToReturn.Add(IsDeathHere(position + new SnakeVector2f(-1, 0)));
                    dataToReturn.Add(IsDeathHere(position + new SnakeVector2f(0, -1)));
                    dataToReturn.Add(IsDeathHere(position + new SnakeVector2f(0, 1)));
                    break;
            }

            return dataToReturn;
        }
    }
}

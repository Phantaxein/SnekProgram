﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SFML.System;
using SFML.Window;
using SFML.Graphics;
using Snake.ProgramSystem;

namespace Snake.Game
{
    public class FoodHandler : IFoodHandler
    {
        Food Food;
        SnakeVector2f MapSize;
        public int FoodEaten;
        ICollisionHandler CollisionHandler;
        ISnake Snake;
        public FoodHandler(SnakeVector2f mapSize, ICollisionHandler collisionHandler, ISnake snake)
        {
            CollisionHandler = collisionHandler;
            MapSize = mapSize;
            Snake = snake;
            Food = new Food(this, new SnakeVector2f(0, 0), CollisionHandler);

            SpawnFood();
        }

        public void Update()
        {

        }

        public void SpawnFood()
        {
                SnakeVector2f FoodPlacement = new SnakeVector2f(0, 0);

                do
                {
                    int foodX = Map.Rng.Next(1, (int)MapSize.X - 1);
                    int foodY = Map.Rng.Next(1, (int)MapSize.Y - 1);
                    FoodPlacement = new SnakeVector2f(foodX, foodY);
                } while (Food.Position == FoodPlacement || Food.Position == Snake.GetPosition());

            Food = new Food(this, FoodPlacement, CollisionHandler);
        }

        public void Draw(RenderTarget target, RenderStates states)
        {
            Food.Draw(target, states);
        }

        public void RemoveFood(Food food)
        {
            FoodEaten++;
            SpawnFood();
        }

        public double GetData(Snake.Direction direction, SnakeVector2f position)
        {
            SnakeVector2f distanceXY = Food.Position - position;
            var Radian = Math.Atan2(-distanceXY.X, distanceXY.Y);
            var degrees = Radian * 180.0 / Math.PI;

            switch (direction)
            {
                case Game.Snake.Direction.Up: degrees += 180; break;
                case Game.Snake.Direction.Right: degrees += 90; break;
                case Game.Snake.Direction.Down: degrees += 0; break;
                case Game.Snake.Direction.Left: degrees += 270; break;
            }
            degrees %= 360;
            degrees = degrees / 180;

            

            if(degrees > 1)
            {
                degrees = ((degrees - 1) * -1);
            }

            return degrees;
        }

        //public int[] GetData()
        //{
        //    int[] dataToGet = new int[(int)MapSize.X * (int)MapSize.Y];

        //    for (int i = 0; i < dataToGet.Length; i++)
        //    {
        //        int posX = (int)(i % MapSize.X);
        //        int posY = (int)(i / MapSize.X);

        //        if (Foods.Any(x => x.Position.X == posX && x.Position.Y == posY))
        //        {
        //            dataToGet[i] = 1;
        //        }
        //        else
        //        {
        //            dataToGet[i] = 0;
        //        }
        //    }

        //    return dataToGet;
        //}
    }
}

﻿using Snake.ProgramSystem;
using System;

namespace Snake.Game
{
    public interface ICollisionHandler
    {
        void Register(ICollider collider);
        void Remove(ICollider collider);
        Type RequestMove(SnakeRectangle requestedPosition, ICollider requestor);
        Type AskForMove(SnakeRectangle requestedPosition, ICollider requestor);
    }
}
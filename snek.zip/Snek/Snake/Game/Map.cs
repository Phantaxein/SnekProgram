﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SFML.System;
using SFML.Window;
using SFML.Graphics;
using Snake.ProgramSystem;

namespace Snake.Game
{
    public class Map
    {
        [ThreadStatic] public static Random Rng;
        List<Wall> Walls;
        Snake snake;
        SnakeVector2f Size;
        SnakeVector2f Position;
        FoodHandler foodHandler;
        RectangleShape rectangleShape;
        CollisionHandler collisionHandler;


        public Map(int seed)
        {
            Rng = new Random(seed);
            collisionHandler = new CollisionHandler();
            Walls = new List<Wall>();
            snake = new Snake(collisionHandler);

            Size = new SnakeVector2f(18, 18);
            Position = new SnakeVector2f(10, 10);
            SetUpWalls();

            rectangleShape = new RectangleShape(Size)
            {
                Position = Position,
                OutlineColor = Color.White,
                OutlineThickness = -1,
                FillColor = new Color(30, 30, 30),
            };

            foodHandler = new FoodHandler(Size, collisionHandler, snake);
        }

        public void SetRNG(int seed)
        {
            Rng = new Random(seed);
        }

        

        public int GetSteps()
        {
            return snake.MoveCounter;
        }

        private void SetUpWalls()
        {
            Walls.Add(new Wall(new SnakeVector2f(1, Size.Y), new SnakeVector2f(0, 0), collisionHandler));
            Walls.Add(new Wall(new SnakeVector2f(1, Size.Y), new SnakeVector2f(Size.X - 1, 0), collisionHandler));
            Walls.Add(new Wall(new SnakeVector2f(Size.X, 1), new SnakeVector2f(0, 0), collisionHandler));
            Walls.Add(new Wall(new SnakeVector2f(Size.X, 1), new SnakeVector2f(0, Size.Y - 1), collisionHandler));
        }
        public void Update()
        {
            
                snake.Update();
                foodHandler.Update();
        }

        public void KeyPress(int key)
        {
            snake.KeyPress(key);
        }

        public void Draw(RenderTarget target, RenderStates states)
        {
            rectangleShape.Draw(target, states);

            states.Transform.Translate(Position);

            Walls.ForEach(x => x.Draw(target, states));

            foodHandler.Draw(target, states);

            snake.Draw(target, states);
        }

        public double[] GetData()
        {
            List<double> dataToReturn = new List<double>();

            var direction = snake.GetDirection();

            List<double> data = collisionHandler.GetData(direction, snake.Position);

            dataToReturn.AddRange(data);
            dataToReturn.Add(foodHandler.GetData(direction, snake.Position));

            return dataToReturn.ToArray();
        }

        public bool IsRunning()
        {
            return !snake.IsDead;
        }

        public int GetScore()
        {
            return foodHandler.FoodEaten;
        }
    }
}
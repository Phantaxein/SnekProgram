﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SFML.System;

namespace Snake.ProgramSystem
{
    public class SnakeRectangle
    {
        public SnakeRectangle(SnakeVector2f position, SnakeVector2f size)
        {
            Position = position;
            Size = size;
        }

        public SnakeVector2f Position;
        public SnakeVector2f Size;

        public bool Collides(SnakeRectangle snakeRectangle)
        {
            return  !(snakeRectangle.Position.X >= Position.X + Size.X
                    || snakeRectangle.Position.X + snakeRectangle.Size.X <= Position.X
                    || snakeRectangle.Position.Y >= Position.Y + Size.Y
                    || snakeRectangle.Position.Y + snakeRectangle.Size.Y <= Position.Y);
        }

        public bool Collides(SnakeVector2f position)
        {
            return Collides(new SnakeRectangle(position, new SnakeVector2f(1, 1)));
        }
    }
}

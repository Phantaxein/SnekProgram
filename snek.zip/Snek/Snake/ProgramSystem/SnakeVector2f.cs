﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SFML.System;

namespace Snake.ProgramSystem
{
    public class SnakeVector2f
    {
        static int Unit = 16;

        public float X;
        public float Y;
        
        public SnakeVector2f(float x, float y, bool IsTransformed = false)
        {
            if (IsTransformed)
            {
                X = x / Unit;
                Y = y / Unit;
            }
            else
            {
                X = x;
                Y = y;
            }
        }

        public float TransformedX
        {
            get
            {
                return X * Unit;
            }
        }

        public float TransformedY
        {
            get
            {
                return Y * Unit;
            }
        }

        public Vector2f Raw
        {
            get
            {
                return new Vector2f(X, Y);
            }
        }

        public static Vector2f CenterOffSet(Vector2f size)
        {
            return new Vector2f((Unit - size.X) / 2F, (Unit - size.Y) / 2F);
        }

        public override bool Equals(object obj)
        {
            return this == (SnakeVector2f)obj;
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        public static implicit operator SnakeVector2f(Vector2f b)
        {
            return new SnakeVector2f(b.X / Unit, b.Y / Unit);
        }

        public static implicit operator Vector2f(SnakeVector2f m)
        {
            return new Vector2f(m.TransformedX, m.TransformedY);
        }

        public static SnakeVector2f operator +(SnakeVector2f Left, SnakeVector2f Right)
        {
            return new SnakeVector2f(Left.X + Right.X, Left.Y + Right.Y);
        }

        public static SnakeVector2f operator -(SnakeVector2f Left, SnakeVector2f Right)
        {
            return new SnakeVector2f(Left.X - Right.X, Left.Y - Right.Y);
        }

        public static SnakeVector2f operator *(SnakeVector2f Left, SnakeVector2f Right)
        {
            return new SnakeVector2f(Left.X * Right.X, Left.Y * Right.Y);

        }
        public static SnakeVector2f operator /(SnakeVector2f Left, SnakeVector2f Right)
        {
            return new SnakeVector2f(Left.X / Right.X, Left.Y / Right.Y);
        }

        public static bool operator ==(SnakeVector2f Left, SnakeVector2f Right)
        {
            return Left.X == Right.X && Left.Y == Right.Y;
        }

        public static bool operator !=(SnakeVector2f Left, SnakeVector2f Right)
        {
            return Left.X != Right.X || Left.Y != Right.Y;
        }

    }
}

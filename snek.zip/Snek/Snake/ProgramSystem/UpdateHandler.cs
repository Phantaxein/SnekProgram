﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SFML.System;
using SFML.Window;
using SFML.Graphics;

namespace Snake.Game
{
    public class UpdateHandler
    {
        public int UpdatesNeededToTrigger;

        int CurrentUpdateTick;
        public UpdateHandler(int updatesNeededToTrigger)
        {
            UpdatesNeededToTrigger = updatesNeededToTrigger;
        }

        public void ChangeUpdateRate(int value)
        {
            UpdatesNeededToTrigger = value;
        }

        public bool Update()
        {
            CurrentUpdateTick++;

            if(CurrentUpdateTick >= UpdatesNeededToTrigger)
            {
                CurrentUpdateTick = 0;
                return true;
            }

            return false;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using SFML.Graphics;
using SFML.Window;
using SFML.System;
using SFML.Audio;
using System.Text;
using System.Timers;
using System.Threading.Tasks;
using Snake.Game;

namespace TheHandler
{
    public class TrialSystem
    {

        int lastKey = 0;

        RenderWindow _Window;
        RenderWindow Window
        {
            get
            {
                if (_Window == null)
                {
                    _Window = new RenderWindow(VideoMode.DesktopMode, "Trial One", Styles.Fullscreen);
                    _Window.MouseButtonPressed += new EventHandler<MouseButtonEventArgs>(MousePress);
                    _Window.MouseButtonReleased += new EventHandler<MouseButtonEventArgs>(MouseRelease);
                    _Window.MouseMoved += new EventHandler<MouseMoveEventArgs>(MouseMove);
                    _Window.KeyPressed += new EventHandler<KeyEventArgs>(KeyPress);
                    _Window.MouseButtonReleased += new EventHandler<MouseButtonEventArgs>(MouseRelease);
                    Window.SetFramerateLimit(60);
                    //_Window.SetMouseCursorVisible(false);
                }

                return _Window;
            }
        }

        public TrialSystem()
        {
        }

        public void Run()
        {
            RenderStates rs = RenderStates.Default;
            Map myMap = new Map(1);
            int updateTime = 0;
            while (Window.IsOpen)
            {
                //Event Check
                Window.DispatchEvents();
                //Update
                myMap.KeyPress(lastKey);
                updateTime++;
                if (updateTime % 30 == 0)
                {
                    myMap.Update();
                    updateTime = 0;
                }

                //Draw
                Window.Clear();
                myMap.Draw(Window, rs);
                Window.Display();
            }
        }

        public void KeyPress(object sender, KeyEventArgs e)
        {
            switch (e.Code)
            {
                case Keyboard.Key.Escape: Window.Close(); break;
                case Keyboard.Key.W: lastKey = (int)Snake.Game.Snake.Direction.Up; break;
                case Keyboard.Key.A: lastKey = (int)Snake.Game.Snake.Direction.Left; break;
                case Keyboard.Key.S: lastKey = (int)Snake.Game.Snake.Direction.Down; break;
                case Keyboard.Key.D: lastKey = (int)Snake.Game.Snake.Direction.Right; break;
            }

        }

        public void MouseMove(object sender, MouseMoveEventArgs e)
        {
        }

        public void MousePress(object sender, MouseButtonEventArgs e)
        {

        }

        public void MouseRelease(object sender, MouseButtonEventArgs e)
        {

        }
    }
}
﻿namespace NeuralNetwork.NetworkSystem
{
    public interface INeuron
    {
        void Receive(double value);
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SFML.System;
using SFML.Graphics;
using SFML.Window;

namespace NeuralNetwork.NetworkSystem
{
    public partial class Network : INetwork
    {
        [ThreadStatic] public static Random rng;

        public static Random Rng
        {
            get
            {
                if(rng == null)
                {
                    rng = new Random();
                }

                return rng;
            }
            set
            {
                rng = value;
            }
        }

        Layer[] NetworkLayers;
        public double Fitness;
        public Network(int seed)
        {
            Rng = new Random(seed);
        }

        public Network(Network parentOne, Network parentTwo, double neuronMutationRate = 0.05, double dendriteMutationRate = 0.05)
        {
            List<Layer> childLayers = new List<Layer>();

            for (int i = 0; i < parentOne.NetworkLayers.Count(); i++)
            {
                childLayers.Add(new Layer(parentOne.NetworkLayers[i], parentTwo.NetworkLayers[i], neuronMutationRate, dendriteMutationRate));
            }

            NetworkLayers =  childLayers.ToArray();

            BindExisting();
        }

        private void Bind()
        {
            for (int i = 0; i < NetworkLayers.Length - 1; i++)
            {
                NetworkLayers[i].Connect(NetworkLayers[i + 1]);
            }
        }

        private void BindExisting()
        {
            for (int i = 0; i < NetworkLayers.Length - 1; i++)
            {
                NetworkLayers[i].ConnectExisting(NetworkLayers[i + 1]);
            }
        }

        public void ProvideData(double[] values)
        {
            NetworkLayers[0].ProvideData(values);

            foreach (Layer layer in NetworkLayers)
            {
                layer.Process();
            }
        }

        public void ProvideData(string[] values)
        {
            List<double> convertedData = new List<double>();

            foreach (string value in values)
            {
                double.TryParse(value, out double x);
                convertedData.Add(x);
            }

            ProvideData(convertedData.ToArray());
        }

        public int GetResult()
        {
            return NetworkLayers.Last().GetResult();
        }

        public void GenerateLayers(int[] layerSize)
        {
            NetworkLayers = new Layer[layerSize.Length];

            for (int i = 0; i < layerSize.Length; i++)
            {
                float x = i * (Size.X - 70) / (layerSize.Length - 1);
                float y = (Size.Y - 45 * layerSize[i] + 25) / 2;
                Vector2f pos = new Vector2f(x, y);
                NetworkLayers[i] = new Layer(layerSize[i], pos);
            }
        }

        public void CalculateRewardFunction(int score, int StepsTaken)
        {
            Fitness = (score * score * score);
        }
    }

    public partial class Network : Drawable
    {
        Vector2f Position;
        Vector2f Size;
        bool IsViewPortActive;
        Vector2f ViewPortOffset;
        Vector2f OnClickInitialPosition;
        public Network(int[] networkLayers, FloatRect rect, int seed) : this(seed)
        {
            Position = new Vector2f(rect.Left, rect.Top);
            Size = new Vector2f(rect.Width, rect.Height);
            ViewPortOffset = new Vector2f(0, 0);
            OnClickInitialPosition = new Vector2f(0, 0);
            IsViewPortActive = false;
            GenerateLayers(networkLayers);
            Bind();
        }

        public void Draw(RenderTarget target, RenderStates states)
        {
            states.Transform.Translate(Position + ViewPortOffset);

            foreach (Layer layer in NetworkLayers)
            {
                layer.Draw(target, states);
            }
        }

        public void Click(Vector2f location)
        {
            IsViewPortActive = true;
            OnClickInitialPosition = location;

            location -= Position;

            foreach (Layer layer in NetworkLayers)
            {
                layer.Click(location);
            }
        }

        public void ClickRelease()
        {
            IsViewPortActive = false;
        }

        public void MouseMove(Vector2f position)
        {
            if(IsViewPortActive)
            {
                ViewPortOffset += position - OnClickInitialPosition;
                OnClickInitialPosition = position;
            }
        }

    }
}

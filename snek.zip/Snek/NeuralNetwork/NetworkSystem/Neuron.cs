﻿using SFML.Graphics;
using SFML.System;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NeuralNetwork.NetworkSystem
{
    public partial class Neuron : INeuron
    {
        public double Bias;
        public List<Dendrite> OutBound;
        public double IncomingValues;
        public double Value;

        internal Neuron()
        {
            Bias = (Network.Rng.NextDouble() * 2) - 1;
            OutBound = new List<Dendrite>();
        }

        public Neuron(Neuron parentOne, Neuron parentTwo, double neuronMutationRate, double dendriteMutationRate)
        {
            //Bias = (parentOne.Bias + parentTwo.Bias) / 2;
            Bias = Network.Rng.Next(0, 2) == 0 ? parentOne.Bias : parentTwo.Bias;
            Bias += (((Network.Rng.NextDouble() * 2) - 1) * neuronMutationRate * Bias);

            List<Dendrite> childDendrites = new List<Dendrite>();

            for (int i = 0; i < parentOne.OutBound.Count; i++)
            {
                childDendrites.Add(new Dendrite(parentOne.OutBound[i], parentTwo.OutBound[i], dendriteMutationRate, null));
            }

            OutBound = childDendrites;
        }

        public void Receive(double value)
        {
            IncomingValues += value;
        }

        public void Process()
        {
            double valueToShrink = IncomingValues + Bias;

            IncomingValues = 0;

            Value = ReLU(valueToShrink);

            if (Value > 0)
            {
                Fire(Value);
            }
        }

        public void Connect(Neuron neuron, Vector2f positionOffset)
        {
            Dendrite connection = new Dendrite(neuron, CenterPosition, neuron.CenterPosition + positionOffset);

            OutBound.Add(connection);
        }

        public void ConnectExisting(int index, Neuron neuron)
        {
            OutBound[index].Neuron = neuron;
        }

        private static double ReLU(double value)
        {
            return Math.Max(0, value);
        }

        private void Fire(double value)
        {
            foreach (Dendrite dendrite in OutBound)
            {
                dendrite.Fire(value);
            }
        }
    }

    public partial class Neuron
    {
        CircleShape CircleShape;

        Vector2f CenterPosition
        {
            get
            {
                return new Vector2f(CircleShape.Position.X + (CircleShape.Radius), CircleShape.Position.Y + (CircleShape.Radius));
            }
        }

        public Neuron(Vector2f position) : this()
        {
            CircleShape = new CircleShape
            {
                Radius = 10,
                OutlineColor = Color.White,
                OutlineThickness = 1,
                FillColor = Color.Transparent,
                Position = position
            };
        }

        public void Draw(RenderTarget target, RenderStates states)
        {
            CircleShape.Draw(target, states);

            foreach (Dendrite dendrite in OutBound)
            {
                dendrite.Draw(target, states);
            }
        }

        public void Click(Vector2f location)
        {
            location -= CircleShape.Position;

            if (location.X >= 0 && location.Y >= 0 && location.X < 10 && location.Y < 10)
            {
                CircleShape.FillColor = new Color((byte)Network.Rng.Next(0, 256), (byte)Network.Rng.Next(0, 256), (byte)Network.Rng.Next(0, 256));
            }
            else
            {
                CircleShape.FillColor = Color.Transparent;
            }
        }
    }
}

﻿using SFML.Graphics;
using SFML.System;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NeuralNetwork.NetworkSystem
{
    public partial class Layer
    {
        public Neuron[] Neurons;
        private Layer(int neurons)
        {
            Neurons = new Neuron[neurons];

            for (int i = 0; i < Neurons.Length; i++)
            {
                Neurons[i] = new Neuron(new Vector2f(0, i * 45));
            }
        }

        public Layer(Layer parentOne, Layer ParentTwo, double neuronMutationRate, double dendriteMutationRate)
        {
            List<Neuron> childNeurons = new List<Neuron>();

            for (int i = 0; i < parentOne.Neurons.Length; i++)
            {
                childNeurons.Add(new Neuron(parentOne.Neurons[i], ParentTwo.Neurons[i], neuronMutationRate, dendriteMutationRate));
            }

            Neurons = childNeurons.ToArray();
        }

        public void Process()
        {
            foreach (Neuron neuron in Neurons)
            {
                neuron.Process();
            }
        }

        public void ProvideData(double[] values)
        {
            for (int i = 0; i < Neurons.Length; i++)
            {
                Neurons[i].Receive(values[i]);
            }
        }

        public void Connect(Layer layer)
        {
            foreach (Neuron currentLayer in Neurons)
            {
                foreach (Neuron connectingLayer in layer.Neurons)
                {
                    currentLayer.Connect(connectingLayer, layer.Position - Position);
                }
            }
        }

        public void ConnectExisting(Layer layer)
        {
            for (int i =0; i < Neurons.Length; i++)
            {
                for (int x = 0; x < layer.Neurons.Length; x++)
                {
                    Neurons[i].ConnectExisting(x, layer.Neurons[x]);
                }
            }
        }

        public int GetResult()
        {
            int NeuronIndex = 0;

            for (int i = 1; i < Neurons.Length; i++)
            {
                if (Neurons[i].Value > Neurons[NeuronIndex].Value)
                {
                    NeuronIndex = i;
                }
                Neurons[i].IncomingValues = 0;
            }

            return NeuronIndex;
        }
    }

    public partial class Layer
    {
        Vector2f Position;

        public Layer(int neurons, Vector2f position) : this(neurons)
        {
            Position = position;
        }

        public void Draw(RenderTarget target, RenderStates states)
        {
            states.Transform.Translate(Position);

            for (int i = 0; i < Neurons.Length; i++)
            {
                Neurons[i].Draw(target, states);
            }
        }

        public void Click(Vector2f location)
        {
            location -= Position;

            foreach(Neuron neuron in Neurons)
            {
                neuron.Click(location);
            }
        }
    }
}
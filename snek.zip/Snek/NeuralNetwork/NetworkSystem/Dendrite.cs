﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SFML.Graphics;
using SFML.System;

namespace NeuralNetwork.NetworkSystem
{
    public partial class Dendrite
    {
        public double Weight;
        public INeuron Neuron;

        public Dendrite(INeuron neuron)
        {
            Neuron = neuron;
            Weight = (Network.Rng.NextDouble() * 2) - 1;
        }
        public Dendrite(Dendrite parentOne, Dendrite parentTwo, double dendriteMutationRate, INeuron neuron)
        {
            Neuron = neuron;
            //Weight = (parentOne.Weight + parentTwo.Weight) / 2;
            Weight = Network.Rng.Next(0, 2) == 0 ? parentOne.Weight : parentTwo.Weight;
            Weight += (((Network.Rng.NextDouble() * 2) - 1) * dendriteMutationRate * Weight);
        }
        public void Fire(double value)
        {
            Neuron.Receive(value * Weight);
        }
    }

    public partial class Dendrite
    {
        VertexArray line;

        public Dendrite(INeuron neuron, Vector2f startPosition, Vector2f endPosition) : this(neuron)
        {
            line = new VertexArray(PrimitiveType.Lines);
            byte colorPower = (byte)(255 * Math.Abs(Weight));
            Color color = new Color((byte)(Weight < 0 ? colorPower : 255 - colorPower), (byte)(Weight > 0 ? colorPower : 255 - colorPower), 0);
            line.Append(new Vertex(startPosition, color));
            line.Append(new Vertex(endPosition, color));
        }

        public void Draw(RenderTarget target, RenderStates states)
        {
            line.Draw(target, states);
        }

        public void Click(Vector2f location)
        {

        }
    }
}
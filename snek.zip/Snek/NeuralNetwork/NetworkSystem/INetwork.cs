﻿namespace NeuralNetwork.NetworkSystem
{
    public interface INetwork
    {
        void ProvideData(double[] values);

        int GetResult();
    }
}